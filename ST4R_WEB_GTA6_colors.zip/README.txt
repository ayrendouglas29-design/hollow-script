ST4R WEB

Upload the contents of this ZIP to Cloudflare Pages (direct upload).

Includes:
- ST4R WEB branding and translucent title text
- Snowboard image background (st4r-snow-background.jpeg)
- Existing browser shortcuts and in-page site selector
- Accent colors and custom background upload
- Improved ST4R AI chat helper

AI note: the built-in assistant provides local navigation/help responses. For full generative AI, configure a secure server endpoint in Settings. Do not put a private API key in index.html or the browser.
Some third-party websites block iframe embedding; ST4R WEB cannot override those site policies.
